from . import main
# Calls main function.
if __name__ == "__main__":
    main()